# Seq2SeqLearn

Seq2SeqLearn Library is a sequence to sequence learning library written in c#  .net.

sequence to sequence learning is a general framework that can be used for machine translations, Chabot or any other sequence classifications problems.
# LSTM
LSTM neural network like recurrent neural network used to predict the next element in a time series or sequence.
sequence to sequence learning process contain two main blocks Encoder and Decoder.
# Encoder
Encoder map the input sequence to fixed length vector.
# Decoder
take the encoded vector and predict the output sequence.
the library uses the idea of automatic differentiation 


License
----

MIT

